﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Web;

public partial class ReadMeFiles_ReadMe : System.Web.UI.Page
{


    public static string file = "ReadMe.Json";
    protected void Page_Load(object sender, EventArgs e)
    {
        try

        {

            if (!IsPostBack)
            {
              
                LoadJson();
            }


        }
        catch (Exception ex)
        {

            
        }
       
    }

    public  void LoadJson()
    {
        string path = HttpContext.Current.Server.MapPath(@"~/ReadMeFiles/" + file);

        using (StreamReader r = new StreamReader(path))
        {
            var json = r.ReadToEnd();
            
            var items = JsonConvert.DeserializeObject<List<SchemaInfo>>(json) ;
           
            items.Reverse();

            Repeater_accordion.DataSource = items;
            Repeater_accordion.DataBind();

        }
    }


    public void WriteJson()
    {
        string path = HttpContext.Current.Server.MapPath(@"~/ReadMeFiles/" + file);

        using (StreamReader r = new StreamReader(path))
        {
            string json = r.ReadToEnd();
 
            r.Close();





                        if (json.Length == 0)
            {
                List<SchemaInfo> _data = new List<SchemaInfo>();
                _data.Add(new SchemaInfo()
                {
                    ProjectName = txtProject.Text,
                    DeveloperName = txtName.Text,
                    Version = txtVersion.Text,
                    Date = DateTime.Now.ToString(),
                    Discription = "<pre>"+ txtDescription.Text + "</pre>"  ,
                    ID = DateTime.Now.ToString("yyMMddHHmm"),
                });

                string json1 = JsonConvert.SerializeObject(_data, Formatting.Indented);

                //write string to file
               File.WriteAllText(path, json1);
                

            }
            else
            {
                var list = JsonConvert.DeserializeObject<List<SchemaInfo>>(json);
                list.Add(new SchemaInfo()
                {
                    ProjectName = txtProject.Text,
                    DeveloperName = txtName.Text,
                    Version = txtVersion.Text,
                    Date = DateTime.Now.ToString(),
                    Discription = "<pre>" + txtDescription.Text + "</pre>",
                    ID = DateTime.Now.ToString("yyMMddHHmm"),


                });
                string convertedJson = JsonConvert.SerializeObject(list, Formatting.Indented);
                
                File.WriteAllText(path, convertedJson);


            }


        }
           
    }



   
    public class SchemaInfo
    {
        public string ID { get; set; }
        public string ProjectName { get; set; }
        public string DeveloperName { get; set; }
        public string Version { get; set; }
        public string Date { get; set; }
        public string Discription { get; set; }


    }

protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            if (!string.IsNullOrEmpty(txtDescription.Text) || !string.IsNullOrEmpty(txtName.Text)|| 
                !string.IsNullOrEmpty(txtProject.Text)|| !string.IsNullOrEmpty(txtVersion.Text) )
            {
                WriteJson();
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert( 'Field Empty! try again' )</script>");

            }
            
        }
        catch (Exception ex)
        {


        }
        finally {

            LoadJson();

            txtDescription.Text = txtName.Text = txtProject.Text = txtVersion.Text = "";
        

        }
    }




   
}